#!/bin/bash
# First-time setup script

echo "Setting up Community Highlighter..."
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 is required"
    echo "Download from: https://www.python.org/downloads/"
    exit 1
fi

echo "[*] Installing dependencies..."
pip3 install -r requirements.txt

echo ""
echo "[*] Creating .env file..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "    Created .env from template"
    echo ""
    echo "[!] IMPORTANT: Edit .env and add your OpenAI API key"
    echo "    Open .env in a text editor and replace 'sk-your-key-here'"
else
    echo "    .env already exists"
fi

echo ""
echo "Setup complete! Run with: python3 desktop_app.py"
