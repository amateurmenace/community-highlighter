# Community Highlighter - Desktop App

Analyze YouTube meeting transcripts with AI-powered insights.

## Quick Start

### First Time Setup

**Mac/Linux:**
```bash
./setup.sh
```

**Windows:**
```
Double-click setup.bat
```

Then edit `.env` and add your OpenAI API key.

### Running the App

**Mac/Linux:**
```bash
./run.sh
# or
python3 desktop_app.py
```

**Windows:**
```
Double-click run.bat
# or
python desktop_app.py
```

## Features

- ✅ Fetch YouTube transcripts
- ✅ AI-powered summaries
- ✅ Entity extraction (people, places, organizations)
- ✅ Word frequency analysis
- ✅ Sentiment analysis
- ✅ Action items extraction
- ✅ Video clip downloads (desktop only)
- ✅ Highlight reels (desktop only)

## Requirements

- Python 3.9 or later
- OpenAI API key

## Troubleshooting

### "No module named X"
Run the setup script again to install missing dependencies.

### "API key not configured"
Make sure your `.env` file has a valid `OPENAI_API_KEY`.

### "Could not find dist folder"
The frontend wasn't included. Contact the developer.

## Support

Report issues: https://github.com/amateurmenace/community-highlighter/issues
